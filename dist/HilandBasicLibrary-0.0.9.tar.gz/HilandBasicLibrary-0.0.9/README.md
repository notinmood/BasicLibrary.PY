### 公司级别的Python类库 ###

```
  * @emailto: 9727005@qq.com
  * @creator: ShanDong Xiedali
  * @company: HiLand & RainyTop
```

收集常用的代码块，形成类库工具，在多项目中共同使用。