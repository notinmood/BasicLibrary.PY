"""
 * @file   : ServerHelper.py
 * @time   : 14:26
 * @date   : 2021/11/7
 * @mail   : 9727005@qq.com
 * @creator: ShanDong Xiedali
 * @company: HiLand & RainyTop
"""


class ServerHelper:
    @staticmethod
    def get_os_name():
        return "Win"
