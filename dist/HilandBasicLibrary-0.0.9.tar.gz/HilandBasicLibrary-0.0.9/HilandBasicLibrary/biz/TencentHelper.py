"""
 * @file   : TencentHelper.py
 * @time   : 15:16
 * @date   : 2021/11/7
 * @mail   : 9727005@qq.com
 * @creator: ShanDong Xiedali
 * @company: HiLand & RainyTop
"""


def say_hi():
    return "I am a QQ file!"
